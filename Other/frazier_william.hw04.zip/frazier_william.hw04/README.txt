I have no special instructions.
Running __main__.py will cause a few tests cases to run.
create_graph(input) will run the program on any given input (this works for all problems).

The only note is that my equitable_graph.py can print more than 1 coloring if you uncomment the marked sections.