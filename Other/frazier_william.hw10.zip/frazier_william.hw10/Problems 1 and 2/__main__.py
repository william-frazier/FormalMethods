


from zune import *

def run(fc, k, lbl1, lbl2):
    return paths(fc, k, lbl1, lbl2)

def run_full(fc, k):
    return full_paths(fc, k)