Problem 1:
	The code is located in the file z3TicTacToe.py
	In order to test a board, type: 	run(board)
	It will return a statement describing the outcome of the game.

Problem 3:
	The code is located in the file main_4_by_4_nonogram.py
	In order to test a nonogram, type:	run(nonogram)
	The program will print out visualizations of the possible solutions (if there are any) and will return a list of all possible solutions.

Problem 4:
	The code is located in the file sudoku_in_PL.py
	In order to complete a sudoku problem named instance, type:	 run(instance)
	I have left print statements in the code, just commented out but as it stands it will only return a list of all possible solutions, it will not print anything to the screen.

Problem 5:
	The code is located in the file yashi_instance.py 
	When the file is run, it will print one solution to the problem.	