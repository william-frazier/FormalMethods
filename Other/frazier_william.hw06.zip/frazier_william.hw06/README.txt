Each folder contains a file called __main__.py

With this file loaded you can call either 
run(instance) or run_from_file(file)
to invoke z3 on that problem.
Note that I have assumed that each file contains
only one instance (I was unclear on exactly what
Kfoury wanted).