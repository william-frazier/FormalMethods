Pretty straight forward. Just call run(cpt, obs)
to see the result. I have encoded both the example
from piazza (simple_example_of_CPT.pdf) which
I saved in a variable called "instance". I also
encoded the example from Lecture Slides 29
which I called "big_example".