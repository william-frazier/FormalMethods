Pretty straight forward. Just call run(cpt, obs)
to see the result. I have encoded both the example
from piazza (simple_example_of_CPT.pdf) which
I saved in a variable called "instance". I also
encoded the example from Lecture Slides 29
which I called "big_example".

Note as well that a line of logic in this code
expects variables to not be influenced by variables
that come after them alphabetically. It's because
I built this thinking of x_1, x_2 and so on.
Anyway, if that is not the case for one of your
encodings, please update it to reflect this scheme.
